<?php
require_once '../../models/Cliente.php';

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

if (
    !empty($_POST['nombre1']) &&
    !empty($_POST['nombre2']) &&
    !empty($_POST['apellido1'])&&
    !empty($_POST['apellido2'])&&
    !empty($_POST['empresa'])&&
    !empty($_POST['nit'])&&
    !empty($_POST['telefono'])&&
    !empty($_POST['correo'])&&
    !empty($_POST['direccion'])
    ) {
        $nombre1 = htmlspecialchars(trim($_POST['nombre1']));
        $nombre2 = htmlspecialchars(trim($_POST['nombre2']));
        $apellido1 = htmlspecialchars(trim($_POST['apellido1']));
        $apellido2 = htmlspecialchars(trim($_POST['apellido2']));
        $empresa = htmlspecialchars(trim($_POST['empresa']));
        $nit = htmlspecialchars(trim($_POST['nit']));
        $telefono = htmlspecialchars(trim($_POST['telefono']));
        $correo = htmlspecialchars(trim($_POST['correo']));
        $direccion = htmlspecialchars(trim($_POST['direccion']));
    
        try {
            Cliente::guardar($nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion);
            header('Location: ../../views/cliente/buscar.php?mensaje=guardado');
            
            exit;
        } catch (Exception $e) {
            echo "❌ Error al guardar: " . $e->getMessage();
        }
    } else {
        echo "❌ Faltan datos.";
    }
    ?>