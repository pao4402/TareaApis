<?php
require_once '../../models/cliente.php';

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    if ($id) {
        Cliente::eliminar($id);
        header('Location: ../../views/cliente/buscar.php?mensaje=eliminado');
        exit;
    } else {
        echo "❌ ID inválido.";
    }
} else {
    echo "❌ No se recibió ID.";
}
?>
