<?php
require_once '../../models/ApiPaises.php';

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    
    if ($id) {
        $resultado = ApiPais::eliminar($id);
        
        if ($resultado) {
            header('Location: ../../views/api/paises/index.php?mensaje=eliminado');
        } else {
            header('Location: ../../views/api/paises/index.php?error=No se pudo eliminar el país');
        }
        exit;
    } else {
        echo "❌ ID inválido.";
    }
} else {
    echo "❌ No se recibió ID.";
}
?>