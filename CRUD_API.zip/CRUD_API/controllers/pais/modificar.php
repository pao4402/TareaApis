<?php
require_once '../../models/ApiPais.php';

if (
    isset($_POST['id']) &&
    isset($_POST['nombre']) &&
    isset($_POST['nombre_oficial']) &&
    isset($_POST['region'])
) {
    $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
    $nombre = htmlspecialchars(trim($_POST['nombre']));
    $nombre_oficial = htmlspecialchars(trim($_POST['nombre_oficial']));
    $capital = htmlspecialchars(trim($_POST['capital'] ?? ''));
    $region = htmlspecialchars(trim($_POST['region']));
    $poblacion = filter_var($_POST['poblacion'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
    $area = filter_var($_POST['area'] ?? 0, FILTER_VALIDATE_FLOAT) ?: 0;
    $bandera_url = filter_var($_POST['bandera_url'] ?? '', FILTER_VALIDATE_URL) ?: '';
    
    $resultado = ApiPais::actualizar(
        $id,
        $nombre,
        $nombre_oficial,
        $capital,
        $region,
        $poblacion,
        $area,
        $bandera_url
    );
    
    if ($resultado) {
        header('Location: ../../views/api/paises.php?mensaje=modificado');
    } else {
        header('Location: ../../views/api/paises.php?error=No se pudo modificar el país');
    }
    exit;
} else {
    echo "Datos incompletos para modificar.";
}
?>