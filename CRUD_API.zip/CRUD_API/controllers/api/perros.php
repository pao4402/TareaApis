<?php
header('Content-Type: application/json');

require_once '../../models/ApiPerro.php';

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        case 'guardar':
            // Obtener datos del POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método no permitido');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validar datos requeridos
            if (empty($data['raza']) || empty($data['imagen_url'])) {
                throw new Exception('Datos incompletos');
            }
            
            $result = ApiPerro::guardar(
                $data['raza'],
                $data['imagen_url'],
                $data['es_favorito'] ?? 0
            );
            
            echo json_encode($result);
            break;
            
        case 'buscar':
            $raza = $_GET['raza'] ?? '';
            $solo_favoritos = $_GET['solo_favoritos'] === 'true';
            
            $perros = ApiPerro::buscar($raza, $solo_favoritos);
            echo json_encode([
                'exito' => true, 
                'datos' => $perros,
                'cantidad' => count($perros)
            ]);
            break;
            
        case 'obtener':
            // Obtener una raza específica por ID
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID no proporcionado');
            }
            
            $perros = ApiPerro::buscar();
            $perro = null;
            
            foreach ($perros as $p) {
                if ($p['PER_ID'] == $id) {
                    $perro = $p;
                    break;
                }
            }
            
            if (!$perro) {
                throw new Exception('Raza no encontrada');
            }
            
            echo json_encode([
                'exito' => true,
                'datos' => $perro
            ]);
            break;
            
        case 'eliminar':
            $id = $_GET['id'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID no proporcionado');
            }
            
            $result = ApiPerro::eliminar($id);
            echo json_encode([
                'exito' => $result,
                'mensaje' => $result ? 'Raza eliminada correctamente' : 'Error al eliminar raza'
            ]);
            break;
            
        case 'alternar_favorito':
            $id = $_GET['id'] ?? 0;
            $es_favorito = $_GET['es_favorito'] ?? 0;
            
            if (!$id) {
                throw new Exception('ID no proporcionado');
            }
            
            $result = ApiPerro::toggleFavorito($id, $es_favorito);
            echo json_encode([
                'exito' => $result,
                'mensaje' => $result ? 'Favorito actualizado' : 'Error al actualizar favorito'
            ]);
            break;
            
        case 'razas':
            // Obtener lista de razas únicas
            $perros = ApiPerro::buscar();
            $razas = array_unique(array_column($perros, 'PER_RAZA'));
            sort($razas);
            
            echo json_encode([
                'exito' => true,
                'datos' => array_values($razas)
            ]);
            break;
            
        case 'favoritos':
            // Obtener solo favoritos
            $favoritos = ApiPerro::buscar('', true);
            echo json_encode([
                'exito' => true,
                'datos' => $favoritos,
                'cantidad' => count($favoritos)
            ]);
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}
?>