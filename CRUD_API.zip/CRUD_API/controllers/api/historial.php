<?php
header('Content-Type: application/json');

require_once '../../models/ApiHistorial.php';

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        case 'guardar':
            // Obtener datos del POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método no permitido');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validar datos requeridos
            if (empty($data['api_nombre']) || !isset($data['resultados'])) {
                throw new Exception('Datos incompletos');
            }
            
            $result = ApiHistorial::guardar(
                $data['api_nombre'],
                $data['termino_busqueda'] ?? '',
                $data['resultados']
            );
            
            echo json_encode([
                'exito' => $result,
                'mensaje' => $result ? 'Historial guardado' : 'Error al guardar historial'
            ]);
            break;
            
        case 'obtener':
            $api_nombre = $_GET['api'] ?? '';
            
            $historial = ApiHistorial::obtenerHistorial($api_nombre);
            echo json_encode([
                'exito' => true,
                'datos' => $historial,
                'cantidad' => count($historial)
            ]);
            break;
            
        case 'limpiar':
            // Limpiar historial antiguo
            $result = ApiHistorial::limpiarHistorial();
            echo json_encode([
                'exito' => $result,
                'mensaje' => $result ? 'Historial antiguo eliminado' : 'Error al limpiar historial'
            ]);
            break;
            
        case 'estadisticas':
            // Obtener estadísticas del historial
            $historial = ApiHistorial::obtenerHistorial();
            
            // Contar búsquedas por API
            $conteo_apis = array_count_values(array_column($historial, 'HIS_API_NOMBRE'));
            
            // Busquedas más comunes
            $terminos = array_filter(array_column($historial, 'HIS_TERMINO_BUSQUEDA'));
            $busquedas_comunes = array_count_values($terminos);
            arsort($busquedas_comunes);
            
            echo json_encode([
                'exito' => true,
                'datos' => [
                    'total_busquedas' => count($historial),
                    'busquedas_por_api' => $conteo_apis,
                    'terminos_populares' => array_slice($busquedas_comunes, 0, 10, true)
                ]
            ]);
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'exito' => false,
        'mensaje' => $e->getMessage()
    ]);
}
?>