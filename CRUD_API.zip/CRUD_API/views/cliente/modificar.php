<?php

require_once '../../models/Cliente.php';

if (isset($_GET['id'])) {
    $cliente = Cliente::buscarUno($_GET['id']);
}
?>

<?php include_once '../templates/header.php'; ?>
<?php include_once '../templates/navbar.php'; ?>

<div class="container mt-5">
    <h2 class="text-center mb-4 text-white">Modificar Cliente</h2>
    <form action="../../controllers/cliente/modificar.php" method="post" class="p-4 rounded shadow bg-light">
        
        <input type="hidden" name="id" value="<?= $cliente['CLI_ID'] ?>">

        <div class="mb-3">
            <label class="form-label">Primer Nombre:</label>
            <input type="text" name="nombre1" class="form-control" required placeholder="Juan" value="<?= $cliente['CLI_NOMBRE1'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Segundo Nombre (Opcional):</label>
            <input type="text" name="nombre2" class="form-control" placeholder="Pedro" value="<?= $cliente['CLI_NOMBRE2'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Primer Apellido:</label>
            <input type="text" name="apellido1" class="form-control" required placeholder="Rivas" value="<?= $cliente['CLI_APE1'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Segundo Apellido (Opcional):</label>
            <input type="text" name="apellido2" class="form-control" placeholder="Lopez" value="<?= $cliente['CLI_APE2'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Empresa:</label>
            <input type="text" name="empresa" class="form-control" required placeholder="Propimob" value="<?= $cliente['CLI_EMPRESA'] ?>">
        </div>
        
        <div class="mb-3">
            <label class="form-label">NIT:</label>
            <input type="number" name="nit" class="form-control" required placeholder="95214591" value="<?= $cliente['CLI_NIT'] ?>">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Teléfono:</label>
            <input type="number" name="telefono" class="form-control" required placeholder="5555 5555" value="<?= $cliente['CLI_TELEFONO'] ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Correo Electrónico:</label>
            <input type="email" name="correo" class="form-control" required placeholder="nombre@empresa.com" value="<?= $cliente['CLI_CORREO'] ?>">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Dirección:</label>
            <input type="text" name="direccion" class="form-control" required placeholder="1ve 1calle barrio primero zona 1" value="<?= $cliente['CLI_DIRECCION'] ?>">
        </div>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>

<?php include_once '../templates/footer.php'; ?>