<?php require_once '../templates/header.php' ?>

    <!-- Alert Messages -->
    <div class="alert alert-success" id="successAlert">
        <strong>¡Éxito!</strong> <span id="successMessage"></span>
    </div>
    <div class="alert alert-danger" id="errorAlert">
        <strong>¡Error!</strong> <span id="errorMessage"></span>
    </div>

    <div class="container mt-5">
        <!-- API 1: JSONPlaceholder - Usuarios -->
        <div class="api-section" id="usuarios">
            <h2 class="mb-4">API 1: Usuarios (JSONPlaceholder)</h2>
            
            <!-- Formulario de búsqueda -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Buscar Usuario</h5>
                </div>
                <div class="card-body">
                    <form id="searchUserForm">
                        <div class="row">
                            <div class="col-md-4">
                                <input type="text" class="form-control" id="searchName" placeholder="Buscar por nombre">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control" id="searchEmail" placeholder="Buscar por email">
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary w-100">Buscar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Formulario de crear/actualizar -->
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0" id="userFormTitle">Crear Usuario</h5>
                </div>
                <div class="card-body">
                    <form id="userForm">
                        <input type="hidden" id="userId">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Nombre:</label>
                                    <input type="text" class="form-control" id="userName" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email:</label>
                                    <input type="email" class="form-control" id="userEmail" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Teléfono:</label>
                                    <input type="text" class="form-control" id="userPhone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Sitio Web:</label>
                                    <input type="text" class="form-control" id="userWebsite">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success" id="submitBtn">Guardar Usuario</button>
                        <button type="button" class="btn btn-secondary" id="cancelBtn" style="display:none;">Cancelar</button>
                    </form>
                </div>
            </div>

            <!-- Lista de usuarios -->
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Lista de Usuarios</h5>
                </div>
                <div class="card-body">
                    <div class="loading">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="usersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>Teléfono</th>
                                    <th>Sitio Web</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="usersTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- API 2: REST Countries - Países -->
        <div class="api-section" id="paises">
            <h2 class="mb-4">API 2: Países (REST Countries)</h2>
            
            <!-- Búsqueda de países -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Buscar País</h5>
                </div>
                <div class="card-body">
                    <form id="searchCountryForm">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" class="form-control" id="searchCountry" placeholder="Buscar por nombre del país">
                            </div>
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-primary w-100">Buscar País</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Lista de países -->
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Resultados de Países</h5>
                </div>
                <div class="card-body">
                    <div class="loading" id="countriesLoading">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                    </div>
                    <div class="row" id="countriesGrid">
                    </div>
                </div>
            </div>
        </div>

        <!-- API 3: Rick and Morty -->
        <div class="api-section" id="rickmorty">
            <h2 class="mb-4">API 3: Rick and Morty</h2>
            
            <!-- Búsqueda de personajes -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Buscar Personaje</h5>
                </div>
                <div class="card-body">
                    <form id="searchCharacterForm">
                        <div class="row">
                            <div class="col-md-4">
                                <input type="text" class="form-control" id="searchCharacter" placeholder="Nombre del personaje">
                            </div>
                            <div class="col-md-4">
                                <select class="form-control" id="searchStatus">
                                    <option value="">Todos los estados</option>
                                    <option value="alive">Vivo</option>
                                    <option value="dead">Muerto</option>
                                    <option value="unknown">Desconocido</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary w-100">Buscar Personaje</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Lista de personajes -->
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Personajes</h5>
                </div>
                <div class="card-body">
                    <div class="loading" id="charactersLoading">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                    </div>
                    <div class="row" id="charactersGrid">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Variables globales
        let users = [];
        let editingUserId = null;

        // Funciones de utilidad
        function showAlert(type, message) {
            const alertId = type === 'success' ? 'successAlert' : 'errorAlert';
            const messageId = type === 'success' ? 'successMessage' : 'errorMessage';
            
            document.getElementById(messageId).textContent = message;
            const alert = document.getElementById(alertId);
            alert.style.display = 'block';
            
            setTimeout(() => {
                alert.style.display = 'none';
            }, 3000);
        }

        function showLoading(elementId) {
            document.querySelector(`#${elementId} .loading`).style.display = 'block';
        }

        function hideLoading(elementId) {
            document.querySelector(`#${elementId} .loading`).style.display = 'none';
        }

        // API 1: JSONPlaceholder - Usuarios
        async function loadUsers() {
            showLoading('usuarios');
            try {
                const response = await fetch('https://jsonplaceholder.typicode.com/users');
                users = await response.json();
                displayUsers(users);
                showAlert('success', 'Usuarios cargados correctamente');
            } catch (error) {
                showAlert('error', 'Error al cargar usuarios');
            } finally {
                hideLoading('usuarios');
            }
        }

        function displayUsers(usersToDisplay) {
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = '';
            
            usersToDisplay.forEach(user => {
                const row = `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>${user.phone}</td>
                        <td>${user.website}</td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="editUser(${user.id})">Editar</button>
                            <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">Eliminar</button>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += row;
            });
        }

        // Buscar usuarios
        document.getElementById('searchUserForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const searchName = document.getElementById('searchName').value.toLowerCase();
            const searchEmail = document.getElementById('searchEmail').value.toLowerCase();
            
            const filteredUsers = users.filter(user => {
                const nameMatch = user.name.toLowerCase().includes(searchName);
                const emailMatch = user.email.toLowerCase().includes(searchEmail);
                return nameMatch && emailMatch;
            });
            
            displayUsers(filteredUsers);
        });

        // Crear/Actualizar usuario
        document.getElementById('userForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const userData = {
                name: document.getElementById('userName').value,
                email: document.getElementById('userEmail').value,
                phone: document.getElementById('userPhone').value,
                website: document.getElementById('userWebsite').value
            };
            
            try {
                let response;
                if (editingUserId) {
                    // Actualizar
                    response = await fetch(`https://jsonplaceholder.typicode.com/users/${editingUserId}`, {
                        method: 'PUT',
                        body: JSON.stringify({ ...userData, id: editingUserId }),
                        headers: {
                            'Content-type': 'application/json; charset=UTF-8',
                        },
                    });
                    showAlert('success', 'Usuario actualizado correctamente');
                } else {
                    // Crear
                    response = await fetch('https://jsonplaceholder.typicode.com/users', {
                        method: 'POST',
                        body: JSON.stringify(userData),
                        headers: {
                            'Content-type': 'application/json; charset=UTF-8',
                        },
                    });
                    showAlert('success', 'Usuario creado correctamente');
                }
                
                const result = await response.json();
                
                // Actualizar lista localmente
                if (editingUserId) {
                    const index = users.findIndex(u => u.id === editingUserId);
                    if (index !== -1) {
                        users[index] = { ...users[index], ...userData };
                    }
                } else {
                    users.unshift({ ...result, id: users.length + 1 });
                }
                
                displayUsers(users);
                resetUserForm();
                
            } catch (error) {
                showAlert('error', 'Error al guardar usuario');
            }
        });

        function editUser(id) {
            const user = users.find(u => u.id === id);
            if (!user) return;
            
            editingUserId = id;
            document.getElementById('userId').value = id;
            document.getElementById('userName').value = user.name;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userPhone').value = user.phone;
            document.getElementById('userWebsite').value = user.website;
            
            document.getElementById('userFormTitle').textContent = 'Actualizar Usuario';
            document.getElementById('submitBtn').textContent = 'Actualizar Usuario';
            document.getElementById('cancelBtn').style.display = 'inline-block';
            
            // Scroll al formulario
            document.getElementById('userForm').scrollIntoView({ behavior: 'smooth' });
        }

        async function deleteUser(id) {
            if (!confirm('¿Está seguro de eliminar este usuario?')) return;
            
            try {
                await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
                    method: 'DELETE',
                });
                
                users = users.filter(u => u.id !== id);
                displayUsers(users);
                showAlert('success', 'Usuario eliminado correctamente');
                
            } catch (error) {
                showAlert('error', 'Error al eliminar usuario');
            }
        }

        function resetUserForm() {
            document.getElementById('userForm').reset();
            editingUserId = null;
            document.getElementById('userFormTitle').textContent = 'Crear Usuario';
            document.getElementById('submitBtn').textContent = 'Guardar Usuario';
            document.getElementById('cancelBtn').style.display = 'none';
        }

        document.getElementById('cancelBtn').addEventListener('click', resetUserForm);

        // API 2: REST Countries
        async function searchCountries(searchTerm = '') {
            const container = document.getElementById('countriesGrid');
            showLoading('paises');
            
            try {
                let url = 'https://restcountries.com/v3.1/all';
                if (searchTerm) {
                    url = `https://restcountries.com/v3.1/name/${searchTerm}`;
                }
                
                const response = await fetch(url);
                const countries = await response.json();
                
                container.innerHTML = '';
                
                // Limitar a 12 países para mejor visualización
                const limitedCountries = countries.slice(0, 12);
                
                limitedCountries.forEach(country => {
                    const card = `
                        <div class="col-md-3 mb-3">
                            <div class="card h-100">
                                <img src="${country.flags.png}" class="card-img-top" alt="${country.name.common}" style="height: 150px; object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title">${country.name.common}</h5>
                                    <p class="card-text">
                                        <strong>Capital:</strong> ${country.capital ? country.capital[0] : 'N/A'}<br>
                                        <strong>Población:</strong> ${country.population.toLocaleString()}<br>
                                        <strong>Región:</strong> ${country.region}
                                    </p>
                                </div>
                            </div>
                        </div>
                    `;
                    container.innerHTML += card;
                });
                
                showAlert('success', `Se encontraron ${countries.length} países`);
                
            } catch (error) {
                showAlert('error', 'Error al buscar países');
                container.innerHTML = '<p class="text-center">No se encontraron resultados</p>';
            } finally {
                hideLoading('paises');
            }
        }

        document.getElementById('searchCountryForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const searchTerm = document.getElementById('searchCountry').value;
            searchCountries(searchTerm);
        });

        // API 3: Rick and Morty
        async function searchCharacters(name = '', status = '') {
            const container = document.getElementById('charactersGrid');
            showLoading('rickmorty');
            
            try {
                let url = 'https://rickandmortyapi.com/api/character';
                const params = [];
                if (name) params.push(`name=${name}`);
                if (status) params.push(`status=${status}`);
                if (params.length > 0) url += '?' + params.join('&');
                
                const response = await fetch(url);
                const data = await response.json();
                
                container.innerHTML = '';
                
                data.results.forEach(character => {
                    const statusBadge = character.status === 'Alive' ? 'success' : 
                                       character.status === 'Dead' ? 'danger' : 'warning';
                    
                    const card = `
                        <div class="col-md-3 mb-3">
                            <div class="card h-100">
                                <img src="${character.image}" class="card-img-top" alt="${character.name}">
                                <div class="card-body">
                                    <h5 class="card-title">${character.name}</h5>
                                    <p class="card-text">
                                        <span class="badge bg-${statusBadge}">${character.status}</span>
                                        <br><strong>Especie:</strong> ${character.species}
                                        <br><strong>Origen:</strong> ${character.origin.name}
                                    </p>
                                </div>
                            </div>
                        </div>
                    `;
                    container.innerHTML += card;
                });
                
                showAlert('success', `Se encontraron ${data.results.length} personajes`);
                
            } catch (error) {
                showAlert('error', 'Error al buscar personajes');
                container.innerHTML = '<p class="text-center">No se encontraron resultados</p>';
            } finally {
                hideLoading('rickmorty');
            }
        }

        document.getElementById('searchCharacterForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('searchCharacter').value;
            const status = document.getElementById('searchStatus').value;
            searchCharacters(name, status);
        });

        // Inicialización
        document.addEventListener('DOMContentLoaded', () => {
            loadUsers();
            searchCountries();
            searchCharacters();
        });
    </script>
</body>
</html>