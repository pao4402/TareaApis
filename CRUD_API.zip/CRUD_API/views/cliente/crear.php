<?php

include_once '../templates/header.php';
include_once '../templates/navbar.php';
require_once '../../models/Cliente.php';
?>

<div class="container mt-5">
    <h2 class="text-center mb-4 text-white">Registrar un Cliente</h2>
    <form action="../../controllers/cliente/guardar.php" method="post" class="p-4 rounded shadow bg-light">
        <div class="mb-3">
            <label class="form-label">Primer Nombre:</label>
            <input type="text" name="nombre1" class="form-control" required placeholder="Juan">
        </div>

        <div class="mb-3">
            <label class="form-label">Segundo Nombre (Opcional):</label>
            <input type="text" name="nombre2" class="form-control" placeholder="Pedro">
        </div>

        <div class="mb-3">
            <label class="form-label">Primer Apellido:</label>
            <input type="text" name="apellido1" class="form-control" required placeholder="Rivas">
        </div>

        <div class="mb-3">
            <label class="form-label">Segundo Apellido (Opcional):</label>
            <input type="text" name="apellido2" class="form-control" placeholder="Lopez">
        </div>

        <div class="mb-3">
            <label class="form-label">Empresa:</label>
            <input type="text" name="empresa" class="form-control" required placeholder="Propimob">
        </div>
        
        <div class="mb-3">
            <label class="form-label">NIT:</label>
            <input type="number" name="nit" class="form-control" required placeholder="95214591">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Teléfono:</label>
            <input type="number" name="telefono" class="form-control" required placeholder="5555 5555">
        </div>

        <div class="mb-3">
            <label class="form-label">Correo Electrónico:</label>
            <input type="email" name="correo" class="form-control" required placeholder="nombre@empresa.com">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Dirección:</label>
            <input type="text" name="direccion" class="form-control" required placeholder="1ve 1calle barrio primero zona 1">
        </div>

        <button type="submit" class="btn btn-success">Guardar</button>
    </form>
</div>

<?php include_once '../templates/footer.php'; ?>