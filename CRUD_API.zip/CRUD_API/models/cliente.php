
<?php
require_once 'conexion.php';

class Cliente extends Conexion {

    public static function guardar($nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion) {
        try {
            $sql = "INSERT INTO cliente (cli_nombre1, cli_nombre2, cli_ape1, cli_ape2, cli_empresa, cli_nit, cli_telefono, cli_correo, cli_direccion)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion]);
            return true; //  Se guardó
            
        } catch (PDOException $e) {
            error_log('Error al guardar cliente: ' . $e->getMessage());
            return false; //  Falló
        }
    }


     public static function buscar($nombre1 = '', $nombre2 = '', $apellido1 = '', $apellido2 = '', $empresa = '', $nit = '', $telefono = '', $correo = '', $direccion = '') {
        try {
            $sql = "SELECT * FROM cliente WHERE situacion = 1"; 
            $params = [];
    
            if (!empty($nombre1)) {
                $sql .= " AND LOWER(cli_nombre1) LIKE :nombre1";
                $params[':nombre1'] = "%" . strtolower($nombre1) . "%";
            }
            
            if (!empty($nombre2)) {
                $sql .= " AND LOWER(cli_nombre2) LIKE :nombre2";
                $params[':nombre2'] = "%" . strtolower($nombre2) . "%";
            }

            if (!empty($apellido1)) {
                $sql .= " AND LOWER(cli_ape1) LIKE :apellido1";
                $params[':apellido1'] = "%" . strtolower($apellido1) . "%";
            }
    
            if (!empty($apellido2)) {
                $sql .= " AND LOWER(cli_ape2) LIKE :apellido2";
                $params[':apellido2'] = "%" . strtolower($apellido2) . "%";
            }

            if (!empty($empresa)) {
                $sql .= " AND LOWER(cli_empresa) LIKE :empresa";
                $params[':empresa'] = "%" . strtolower($empresa) . "%";
            }

            if (!empty($telefono)) {
                $sql .= " AND CAST(cli_telefono AS CHAR(20)) LIKE :telefono";
                $params[':telefono'] = "%" . $telefono . "%";
            }
    
            if (!empty($nit)) {
                $sql .= " AND CAST(cli_nit AS CHAR(20)) LIKE :nit";
                $params[':nit'] = "%" . $nit . "%";
            }
    
            if (!empty($correo)) {
                $sql .= " AND LOWER(cli_correo) LIKE :correo";
                $params[':correo'] = "%" . strtolower($correo) . "%";
            }

            if (!empty($direccion)) {
                $sql .= " AND LOWER(cli_direccion) LIKE :direccion";
                $params[':direccion'] = "%" . strtolower($direccion) . "%";
            }
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        } catch (PDOException $e) {
            error_log('Error al buscar clientes: ' . $e->getMessage());
            return [];
        }
    }


    public static function eliminar($id) {
        try {
            $sql = "UPDATE cliente SET situacion = 0 WHERE cli_id = ?";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al eliminar cliente: ' . $e->getMessage());
            return false;
        }
    }



        public static function buscarUno($id) {
            try {
                $sql = "SELECT * FROM cliente WHERE cli_id = ?";
                $stmt = self::conectar()->prepare($sql);
                $stmt->execute([$id]);
                return $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log('Error al buscar un cliente: ' . $e->getMessage());
                return false;
            }
        }
    
       
        public static function modificar($id, $nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion) {
            try {
                $sql = "UPDATE cliente SET 
                            cli_nombre1 = ?, 
                            cli_nombre2 = ?, 
                            cli_ape1 = ?, 
                            cli_ape2 = ?,
                            cli_empresa = ?,
                            cli_nit = ?,
                            cli_telefono = ?,
                            cli_correo = ?,
                            cli_direccion = ?
                        WHERE cli_id = ?";
        
                $stmt = self::conectar()->prepare($sql);
                $stmt->execute([$nombre1, $nombre2, $apellido1, $apellido2, $empresa, $nit, $telefono, $correo, $direccion, $id]);
        
                return true;
            } catch (PDOException $e) {
                error_log('Error al modificar cliente: ' . $e->getMessage());
                return false;
            }
        }
}
?>