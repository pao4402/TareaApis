<?php
require_once 'conexion.php';

class ApiHistorial extends Conexion {
    
   
    public static function guardar($api_nombre, $termino_busqueda, $resultados) {
        try {
            
            $fecha_actual = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO api_historial (his_api_nombre, his_termino_busqueda, his_resultados, his_fecha_busqueda)
                    VALUES (?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$api_nombre, $termino_busqueda, $resultados, $fecha_actual]);
            
            return true;
            
        } catch (PDOException $e) {
            error_log('Error al guardar historial: ' . $e->getMessage());
            return false;
        }
    }
    

    public static function obtenerHistorial($api_nombre = '') {
        try {
            $sql = "SELECT * FROM api_historial WHERE situacion = 1";
            $params = [];
            
            if (!empty($api_nombre)) {
                $sql .= " AND his_api_nombre = :api";
                $params[':api'] = $api_nombre;
            }
            
            $sql .= " ORDER BY his_fecha_busqueda DESC FIRST 50";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al obtener historial: ' . $e->getMessage());
            return [];
        }
    }
    

    public static function limpiarHistorial() {
        try {
        
            $sql = "UPDATE api_historial SET situacion = 0 
                    WHERE his_fecha_busqueda < TODAY - 30";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            error_log('Error al limpiar historial: ' . $e->getMessage());
            return false;
        }
    }
}
?>