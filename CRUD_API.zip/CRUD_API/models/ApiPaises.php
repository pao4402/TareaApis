<?php
require_once 'conexion.php';

class ApiPais extends Conexion {
    
    // Guardar país
    public static function guardar($nombre, $nombre_oficial, $capital, $region, $poblacion, $area, $bandera_url) {
        try {
            // Verificar si ya existe
            $sqlCheck = "SELECT pai_id FROM api_paises WHERE pai_nombre = ?";
            $stmtCheck = self::conectar()->prepare($sqlCheck);
            $stmtCheck->execute([$nombre]);
            
            if ($stmtCheck->fetch()) {
                return ['success' => false, 'message' => 'El país ya existe'];
            }
            
            // Obtener fecha actual
            $fecha_actual = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO api_paises (pai_nombre, pai_nombre_oficial, pai_capital, pai_region, pai_poblacion, pai_area, pai_bandera_url, pai_fecha_guardado)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre, $nombre_oficial, $capital, $region, $poblacion, $area, $bandera_url, $fecha_actual]);
            
            return ['success' => true, 'message' => 'País guardado correctamente'];
            
        } catch (PDOException $e) {
            error_log('Error al guardar país: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error al guardar país: ' . $e->getMessage()];
        }
    }
    
    // Buscar países guardados
    public static function buscar($termino = '', $region = '') {
        try {
            $sql = "SELECT * FROM api_paises WHERE situacion = 1";
            $params = [];
            
            if (!empty($termino)) {
                $sql .= " AND LOWER(pai_nombre) LIKE :termino";
                $params[':termino'] = "%" . strtolower($termino) . "%";
            }
            
            if (!empty($region)) {
                $sql .= " AND pai_region = :region";
                $params[':region'] = $region;
            }
            
            $sql .= " ORDER BY pai_nombre ASC";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al buscar países: ' . $e->getMessage());
            return [];
        }
    }
    
    // Buscar un país por ID
    public static function buscarUno($id) {
        try {
            $sql = "SELECT * FROM api_paises WHERE pai_id = ? AND situacion = 1";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al buscar país por ID: ' . $e->getMessage());
            return false;
        }
    }
    
    // Eliminar país (soft delete)
    public static function eliminar($id) {
        try {
            $sql = "UPDATE api_paises SET situacion = 0 WHERE pai_id = ?";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (PDOException $e) {
            error_log('Error al eliminar país: ' . $e->getMessage());
            return false;
        }
    }
    
    // Obtener regiones únicas
    public static function obtenerRegiones() {
        try {
            $sql = "SELECT DISTINCT pai_region FROM api_paises 
                    WHERE situacion = 1 AND pai_region IS NOT NULL 
                    ORDER BY pai_region";
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            error_log('Error al obtener regiones: ' . $e->getMessage());
            return [];
        }
    }
    
    // Actualizar país
    public static function actualizar($id, $nombre, $nombre_oficial, $capital, $region, $poblacion, $area, $bandera_url) {
        try {
            $sql = "UPDATE api_paises SET 
                    pai_nombre = ?, 
                    pai_nombre_oficial = ?, 
                    pai_capital = ?, 
                    pai_region = ?, 
                    pai_poblacion = ?, 
                    pai_area = ?, 
                    pai_bandera_url = ?
                    WHERE pai_id = ? AND situacion = 1";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute([$nombre, $nombre_oficial, $capital, $region, $poblacion, $area, $bandera_url, $id]);
            return true;
            
        } catch (PDOException $e) {
            error_log('Error al actualizar país: ' . $e->getMessage());
            return false;
        }
    }
    
    // Estadísticas de países
    public static function obtenerEstadisticas() {
        try {
            $sql = "SELECT 
                    COUNT(*) as total_paises,
                    COUNT(DISTINCT pai_region) as total_regiones,
                    AVG(pai_poblacion) as poblacion_promedio,
                    MAX(pai_poblacion) as poblacion_maxima,
                    MIN(pai_poblacion) as poblacion_minima
                    FROM api_paises WHERE situacion = 1";
            
            $stmt = self::conectar()->prepare($sql);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log('Error al obtener estadísticas: ' . $e->getMessage());
            return [];
        }
    }
}
?>